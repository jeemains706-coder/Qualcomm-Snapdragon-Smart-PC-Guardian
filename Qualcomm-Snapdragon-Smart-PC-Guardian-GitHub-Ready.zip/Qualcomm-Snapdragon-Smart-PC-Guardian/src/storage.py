from __future__ import annotations

import csv
from pathlib import Path

FIELDS = [
    "timestamp", "cpu_percent", "ram_percent", "ram_used_gb", "cpu_temp_c", "cpu_power_w",
    "gpu_name", "gpu_percent", "vram_percent", "vram_used_mb", "vram_total_mb", "gpu_temp_c",
    "gpu_power_w", "gpu_clock_mhz", "gpu_throttle", "fan_rpm", "battery_percent", "plugged_in",
    "estimated_power_w", "ai_workload", "top_process", "platform"
]


def append_csv(path: str | Path, row: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    clean = {k: row.get(k) for k in FIELDS}
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow(clean)
