from __future__ import annotations

from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd

TARGET = "Appliances"


def make_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    df = df.copy()
    if TARGET not in df.columns:
        raise ValueError(f"Missing target column: {TARGET}")
    if "date" not in df.columns:
        raise ValueError("Expected a 'date' column in energydata_complete.csv")

    dt = pd.to_datetime(df["date"], errors="coerce")
    df["hour"] = dt.dt.hour
    df["minute"] = dt.dt.minute
    df["day_of_week"] = dt.dt.dayofweek
    df["month"] = dt.dt.month
    df["dayofyear"] = dt.dt.dayofyear
    df["weekofyear"] = dt.dt.isocalendar().week.astype(float)
    df["is_weekend"] = (dt.dt.dayofweek >= 5).astype(int)

    minute_of_day = df["hour"] + df["minute"] / 60.0
    df["hour_sin"] = np.sin(2 * np.pi * minute_of_day / 24.0)
    df["hour_cos"] = np.cos(2 * np.pi * minute_of_day / 24.0)
    df["dow_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7.0)
    df["dow_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7.0)
    df.drop(columns=["date"], inplace=True)

    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Past-only features prevent target leakage: every lag/rolling value is from earlier rows.
    past = df[TARGET].shift(1)
    for lag in (1, 2, 3, 6, 12, 18, 36, 72, 144):
        df[f"appliances_lag_{lag}"] = df[TARGET].shift(lag)
    for window in (3, 6, 12, 36):
        df[f"appliances_roll_mean_{window}"] = past.rolling(window).mean()
        df[f"appliances_roll_std_{window}"] = past.rolling(window).std()
        df[f"appliances_roll_max_{window}"] = past.rolling(window).max()
        df[f"appliances_roll_min_{window}"] = past.rolling(window).min()
    df["appliances_delta_1"] = df[TARGET].shift(1) - df[TARGET].shift(2)
    df["appliances_delta_6"] = df[TARGET].shift(1) - df[TARGET].shift(7)
    df["appliances_delta_12"] = df[TARGET].shift(1) - df[TARGET].shift(13)

    y = pd.to_numeric(df[TARGET], errors="coerce")
    X = df.drop(columns=[TARGET]).replace([np.inf, -np.inf], np.nan)

    valid = X.copy()
    valid["__target__"] = y
    valid = valid.dropna(subset=["__target__"])
    if len(valid) > 200:
        valid = valid.iloc[150:].copy()  # Remove rows without the long lag history.

    y = valid.pop("__target__")
    return valid, y


def load_kaggle_csv(csv_path: str | Path) -> pd.DataFrame:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    df = pd.read_csv(path)
    required = {"date", TARGET}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    return df


def train_energy_model(csv_path: str | Path, model_path: str | Path) -> dict[str, Any]:
    """Train 20 candidates (4 model families x 5 seeds) with a time-aware split."""
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import Ridge
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    raw = load_kaggle_csv(csv_path)
    X, y = make_features(raw)
    n = len(X)
    if n < 1000:
        raise ValueError(f"Dataset is too small after feature engineering: {n} rows")

    n_train = int(n * 0.70)
    n_val = int(n * 0.15)
    X_train, y_train = X.iloc[:n_train], y.iloc[:n_train]
    X_val, y_val = X.iloc[n_train:n_train + n_val], y.iloc[n_train:n_train + n_val]
    X_test, y_test = X.iloc[n_train + n_val:], y.iloc[n_train + n_val:]

    def build(kind: str, seed: int):
        if kind == "extra_trees":
            est = ExtraTreesRegressor(
                n_estimators=400, random_state=seed, n_jobs=-1,
                max_features=0.85, min_samples_leaf=1,
            )
        elif kind == "random_forest":
            est = RandomForestRegressor(
                n_estimators=350, random_state=seed, n_jobs=-1,
                max_features=0.80, min_samples_leaf=1,
            )
        elif kind == "hist_gbr":
            est = HistGradientBoostingRegressor(
                learning_rate=0.045, max_iter=450, max_leaf_nodes=31,
                min_samples_leaf=15, l2_regularization=0.2, random_state=seed,
            )
        else:
            return Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                ("ridge", Ridge(alpha=10.0)),
            ])
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", est),
        ])

    def score(model, Xp, yp) -> dict[str, float]:
        pred = model.predict(Xp)
        return {
            "mae_wh": float(mean_absolute_error(yp, pred)),
            "rmse_wh": float(np.sqrt(mean_squared_error(yp, pred))),
            "r2": float(r2_score(yp, pred)),
        }

    candidates: list[tuple[dict[str, float], str, int]] = []
    families = ["extra_trees", "random_forest", "hist_gbr", "ridge"]

    for run_id, (kind, seed) in enumerate(
        ((kind, seed) for kind in families for seed in range(5)), start=1
    ):
        print(f"[{run_id:02d}/20] Training {kind} seed={seed} ...", flush=True)
        candidate = build(kind, seed)
        candidate.fit(X_train, y_train)
        metrics = score(candidate, X_val, y_val)
        print(
            f"    val MAE={metrics['mae_wh']:.2f} | "
            f"RMSE={metrics['rmse_wh']:.2f} | R2={metrics['r2']:.4f}",
            flush=True,
        )
        candidates.append((metrics, kind, seed))

    candidates.sort(key=lambda x: (x[0]["mae_wh"], x[0]["rmse_wh"]))
    best_val, best_kind, best_seed = candidates[0]

    X_trainval = pd.concat([X_train, X_val], axis=0)
    y_trainval = pd.concat([y_train, y_val], axis=0)
    final_model = build(best_kind, best_seed)
    print(f"\nRefitting best configuration: {best_kind} seed={best_seed}", flush=True)
    final_model.fit(X_trainval, y_trainval)
    test_metrics = score(final_model, X_test, y_test)

    feature_importance: dict[str, float] = {}
    estimator = getattr(final_model, "named_steps", {}).get("model", final_model)
    if hasattr(estimator, "feature_importances_"):
        vals = getattr(estimator, "feature_importances_")
        feature_importance = dict(zip(X.columns, [float(v) for v in vals]))

    metrics = {
        **test_metrics,
        "rows": int(len(raw)),
        "feature_rows": int(len(X)),
        "train_rows": int(len(X_trainval)),
        "validation_rows": int(len(X_val)),
        "test_rows": int(len(X_test)),
        "best_model": best_kind,
        "best_seed": int(best_seed),
        "validation_mae_wh": float(best_val["mae_wh"]),
        "validation_rmse_wh": float(best_val["rmse_wh"]),
        "validation_r2": float(best_val["r2"]),
        "runs": 20,
        "mean_target_wh": float(y_trainval.mean()),
        "date_start": str(pd.to_datetime(raw["date"], errors="coerce").min()),
        "date_end": str(pd.to_datetime(raw["date"], errors="coerce").max()),
        "source": "Kaggle/UCI Appliances Energy Prediction dataset (energydata_complete.csv)",
        "target": TARGET,
        "warning": "This model predicts appliance/household energy; it is not a laptop wattmeter or laptop thermal model.",
    }

    bundle = {
        "model": final_model,
        "features": list(X.columns),
        "feature_medians": X_trainval.median(numeric_only=True).to_dict(),
        "metrics": metrics,
        "feature_importance": feature_importance,
        "training_method": "20 candidates: 4 model families x 5 seeds; chronological train/validation/test split",
    }
    output = Path(model_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, output)
    return bundle


def load_energy_model(model_path: str | Path) -> dict[str, Any] | None:
    path = Path(model_path)
    if not path.exists():
        return None
    bundle = joblib.load(path)
    if not isinstance(bundle, dict) or "model" not in bundle:
        raise ValueError(f"Invalid energy model file: {path}")
    return bundle


def predict_energy(bundle: dict[str, Any], values: dict[str, float | int]) -> float:
    features = list(bundle.get("features", []))
    medians = bundle.get("feature_medians", {})
    row = {feature: float(medians.get(feature, 0.0)) for feature in features}

    for key, value in values.items():
        if key in row and value is not None:
            row[key] = float(value)

    hour = float(values.get("hour", 12))
    minute = float(values.get("minute", 0))
    dow = float(values.get("day_of_week", 0))
    row["hour"] = hour
    row["minute"] = minute
    row["day_of_week"] = dow
    row["is_weekend"] = float(values.get("is_weekend", int(dow >= 5)))
    row["hour_sin"] = np.sin(2 * np.pi * (hour + minute / 60.0) / 24.0)
    row["hour_cos"] = np.cos(2 * np.pi * (hour + minute / 60.0) / 24.0)
    row["dow_sin"] = np.sin(2 * np.pi * dow / 7.0)
    row["dow_cos"] = np.cos(2 * np.pi * dow / 7.0)

    X = pd.DataFrame([row], columns=features)
    X = X.replace([np.inf, -np.inf], np.nan)
    for c in X.columns:
        X[c] = pd.to_numeric(X[c], errors="coerce")
        X[c] = X[c].fillna(float(medians.get(c, 0.0)))
    return float(bundle["model"].predict(X)[0])
