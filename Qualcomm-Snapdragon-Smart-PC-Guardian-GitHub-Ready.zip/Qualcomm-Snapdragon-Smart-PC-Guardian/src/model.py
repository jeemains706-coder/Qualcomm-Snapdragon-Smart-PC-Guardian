from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

FEATURES = [
    "cpu_percent", "ram_percent", "vram_percent", "cpu_temp_c",
    "gpu_temp_c", "gpu_power_w", "battery_percent", "plugged_in",
    "ai_workload", "estimated_power_w"
]


def _complete_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in FEATURES:
        if col not in out:
            out[col] = 0.0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0)
    return out[FEATURES]


def generate_synthetic_dataset(rows: int = 6000, seed: int = 42) -> tuple[pd.DataFrame, pd.Series]:
    rng = np.random.default_rng(seed)
    cpu = rng.uniform(5, 100, rows)
    ram = np.clip(rng.normal(62, 20, rows), 15, 99)
    vram = np.clip(rng.normal(48, 28, rows), 0, 100)
    cpu_temp = np.clip(35 + 0.42 * cpu + rng.normal(0, 5, rows), 35, 105)
    gpu_temp = np.clip(35 + 0.32 * vram + 0.20 * cpu + rng.normal(0, 5, rows), 35, 100)
    gpu_power = np.clip(8 + 1.15 * vram + rng.normal(0, 8, rows), 3, 160)
    battery = rng.uniform(5, 100, rows)
    plugged = rng.integers(0, 2, rows)
    ai = rng.integers(0, 2, rows)
    power = np.clip(15 + 0.25 * cpu + 0.75 * gpu_power + rng.normal(0, 6, rows), 8, 220)

    # Synthetic risk label is deliberately conservative for prototype training.
    risk_score = (
        0.035 * np.maximum(cpu_temp - 75, 0)
        + 0.05 * np.maximum(gpu_temp - 75, 0)
        + 0.018 * np.maximum(ram - 82, 0)
        + 0.02 * np.maximum(vram - 88, 0)
        + 0.012 * np.maximum(power - 90, 0)
        + 0.35 * ai
    )
    noise = rng.normal(0, 0.22, rows)
    y = ((risk_score + noise) > 1.0).astype(int)

    df = pd.DataFrame({
        "cpu_percent": cpu,
        "ram_percent": ram,
        "vram_percent": vram,
        "cpu_temp_c": cpu_temp,
        "gpu_temp_c": gpu_temp,
        "gpu_power_w": gpu_power,
        "battery_percent": battery,
        "plugged_in": plugged,
        "ai_workload": ai,
        "estimated_power_w": power,
    })
    return df, pd.Series(y, name="thermal_risk")


def train_and_save(model_path: str | Path) -> dict[str, object]:
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    X, y = generate_synthetic_dataset()

    # Keep a deterministic holdout so the training script can report a quick sanity check.
    n = len(X)
    split = int(n * 0.8)
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y.iloc[:split], y.iloc[split:]

    model = RandomForestClassifier(
        n_estimators=250,
        max_depth=12,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train[FEATURES], y_train)
    pred = model.predict(X_test[FEATURES])
    accuracy = accuracy_score(y_test, pred)

    bundle = {
        "model": model,
        "features": FEATURES,
        "data_note": "Initial model trained on synthetic telemetry for prototype demonstration. Replace/retrain with real labeled laptop telemetry before claiming real-world accuracy.",
    }
    joblib.dump(bundle, model_path)
    return {
        "accuracy": float(accuracy),
        "report": classification_report(y_test, pred, output_dict=True),
        "feature_importance": dict(zip(FEATURES, model.feature_importances_)),
        "model_path": str(model_path),
    }


def load_model(model_path: str | Path):
    bundle = joblib.load(model_path)
    return bundle["model"], bundle["features"], bundle


def predict_risk(model, telemetry: dict) -> tuple[float, str]:
    df = _complete_frame(pd.DataFrame([telemetry]))
    proba = float(model.predict_proba(df)[0][1])
    if proba < 0.30:
        label = "LOW"
    elif proba < 0.65:
        label = "MEDIUM"
    else:
        label = "HIGH"
    return proba, label
