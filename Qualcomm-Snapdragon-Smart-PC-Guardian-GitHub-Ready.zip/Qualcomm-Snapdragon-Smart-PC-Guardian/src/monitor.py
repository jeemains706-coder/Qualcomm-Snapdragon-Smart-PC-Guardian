from __future__ import annotations

import platform
import time
from dataclasses import asdict, dataclass
from typing import Any

import psutil

try:
    import pynvml
    NVML_AVAILABLE = True
except Exception:
    NVML_AVAILABLE = False

try:
    import wmi
    WMI_AVAILABLE = True
except Exception:
    WMI_AVAILABLE = False


@dataclass
class Telemetry:
    timestamp: float
    cpu_percent: float = 0.0
    ram_percent: float = 0.0
    ram_used_gb: float = 0.0
    cpu_temp_c: float | None = None
    cpu_power_w: float | None = None
    gpu_name: str | None = None
    gpu_percent: float = 0.0
    vram_percent: float = 0.0
    vram_used_mb: float = 0.0
    vram_total_mb: float = 0.0
    gpu_temp_c: float | None = None
    gpu_power_w: float | None = None
    gpu_clock_mhz: float | None = None
    gpu_throttle: bool = False
    fan_rpm: float | None = None
    battery_percent: float | None = None
    plugged_in: bool | None = None
    estimated_power_w: float | None = None
    ai_workload: bool = False
    top_process: str | None = None
    platform: str = platform.platform()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class HardwareMonitor:
    def __init__(self) -> None:
        self.nvml_initialized = False
        self.gpu_handle = None
        self.lhm = None
        self._init_nvml()
        self._init_lhm()
        # Prime psutil's CPU counter; the first non-blocking reading is not useful.
        psutil.cpu_percent(interval=None)

    def _init_nvml(self) -> None:
        if not NVML_AVAILABLE:
            return
        try:
            pynvml.nvmlInit()
            self.nvml_initialized = True
            count = pynvml.nvmlDeviceGetCount()
            if count > 0:
                self.gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        except Exception:
            self.nvml_initialized = False
            self.gpu_handle = None

    def _init_lhm(self) -> None:
        if not WMI_AVAILABLE or platform.system().lower() != "windows":
            return
        try:
            self.lhm = wmi.WMI(namespace=r"root\LibreHardwareMonitor")
        except Exception:
            self.lhm = None

    def close(self) -> None:
        if self.nvml_initialized:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
            self.nvml_initialized = False

    @staticmethod
    def _safe_float(value: Any) -> float | None:
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def _lhm_sensors(self) -> list[Any]:
        if self.lhm is None:
            return []
        try:
            return list(self.lhm.Sensor())
        except Exception:
            return []

    def _find_lhm_value(self, sensors: list[Any], sensor_types: set[str], name_terms: list[str]) -> float | None:
        candidates: list[tuple[int, float]] = []
        for s in sensors:
            stype = str(getattr(s, "SensorType", ""))
            name = str(getattr(s, "Name", "")).lower()
            if stype not in sensor_types:
                continue
            if not any(term in name for term in name_terms):
                continue
            value = self._safe_float(getattr(s, "Value", None))
            if value is None:
                continue
            score = sum(2 for term in name_terms if term in name)
            candidates.append((score, value))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][1]

    def _read_lhm(self, sensors: list[Any]) -> dict[str, float | None]:
        return {
            "cpu_temp": self._find_lhm_value(
                sensors, {"Temperature"}, ["cpu package", "package", "cpu"]
            ),
            "cpu_power": self._find_lhm_value(
                sensors, {"Power"}, ["cpu package", "cpu", "package"]
            ),
            "gpu_temp": self._find_lhm_value(
                sensors, {"Temperature"}, ["gpu core", "gpu"]
            ),
            "gpu_power": self._find_lhm_value(
                sensors, {"Power"}, ["gpu power", "gpu"]
            ),
            "fan_rpm": self._find_lhm_value(
                sensors, {"Fan"}, ["cpu fan", "system fan", "fan"]
            ),
        }

    def _read_nvml(self) -> dict[str, Any]:
        result: dict[str, Any] = {}
        if not self.nvml_initialized or self.gpu_handle is None:
            return result
        try:
            h = self.gpu_handle
            result["gpu_name"] = pynvml.nvmlDeviceGetName(h).decode(errors="replace")
        except Exception:
            result["gpu_name"] = None
        try:
            result["gpu_percent"] = float(pynvml.nvmlDeviceGetUtilizationRates(self.gpu_handle).gpu)
        except Exception:
            result["gpu_percent"] = 0.0
        try:
            mem = pynvml.nvmlDeviceGetMemoryInfo(self.gpu_handle)
            result["vram_used_mb"] = mem.used / 1024**2
            result["vram_total_mb"] = mem.total / 1024**2
            result["vram_percent"] = (mem.used / mem.total * 100.0) if mem.total else 0.0
        except Exception:
            result["vram_used_mb"] = 0.0
            result["vram_total_mb"] = 0.0
            result["vram_percent"] = 0.0
        try:
            result["gpu_temp_c"] = float(
                pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)
            )
        except Exception:
            result["gpu_temp_c"] = None
        try:
            result["gpu_power_w"] = float(pynvml.nvmlDeviceGetPowerUsage(h)) / 1000.0
        except Exception:
            result["gpu_power_w"] = None
        try:
            result["gpu_clock_mhz"] = float(
                pynvml.nvmlDeviceGetClockInfo(h, pynvml.NVML_CLOCK_GRAPHICS)
            )
        except Exception:
            result["gpu_clock_mhz"] = None
        try:
            reasons = pynvml.nvmlDeviceGetCurrentClocksThrottleReasons(h)
            # NVML reason bitmask: any non-zero reason means the driver reports a throttle reason.
            result["gpu_throttle"] = int(reasons) != 0
        except Exception:
            result["gpu_throttle"] = False
        return result

    @staticmethod
    def _ai_workload_and_top_process() -> tuple[bool, str | None]:
        ai_terms = (
            "python", "jupyter", "torch", "tensorflow", "onnx", "llama", "ollama",
            "stable-diffusion", "comfy", "blender", "matlab", "cuda", "vs code"
        )
        top_name = None
        top_cpu = -1.0
        ai = False
        for proc in psutil.process_iter(["name", "cpu_percent"]):
            try:
                name = (proc.info.get("name") or "").lower()
                cpu = float(proc.info.get("cpu_percent") or 0.0)
                if cpu > top_cpu:
                    top_cpu = cpu
                    top_name = proc.info.get("name")
                if any(term in name for term in ai_terms) and cpu >= 5.0:
                    ai = True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return ai, top_name

    def sample(self) -> Telemetry:
        cpu_percent = float(psutil.cpu_percent(interval=0.25))
        vm = psutil.virtual_memory()
        battery = psutil.sensors_battery()
        sensors = self._lhm_sensors()
        lhm = self._read_lhm(sensors)
        nvml = self._read_nvml()
        ai_workload, top_process = self._ai_workload_and_top_process()

        cpu_temp = nvml.get("cpu_temp_c") or lhm.get("cpu_temp")
        gpu_temp = nvml.get("gpu_temp_c") or lhm.get("gpu_temp")
        gpu_power = nvml.get("gpu_power_w") or lhm.get("gpu_power")
        cpu_power = lhm.get("cpu_power")
        fan_rpm = lhm.get("fan_rpm")

        # This is a fallback estimate, not a wall-socket measurement.
        estimated_power = None
        known_parts = [p for p in [cpu_power, gpu_power] if p is not None]
        if known_parts:
            estimated_power = sum(known_parts)
        elif gpu_power is not None:
            estimated_power = gpu_power + max(5.0, cpu_percent * 0.35)

        return Telemetry(
            timestamp=time.time(),
            cpu_percent=cpu_percent,
            ram_percent=float(vm.percent),
            ram_used_gb=vm.used / 1024**3,
            cpu_temp_c=cpu_temp,
            cpu_power_w=cpu_power,
            gpu_name=nvml.get("gpu_name"),
            gpu_percent=float(nvml.get("gpu_percent", 0.0)),
            vram_percent=float(nvml.get("vram_percent", 0.0)),
            vram_used_mb=float(nvml.get("vram_used_mb", 0.0)),
            vram_total_mb=float(nvml.get("vram_total_mb", 0.0)),
            gpu_temp_c=gpu_temp,
            gpu_power_w=gpu_power,
            gpu_clock_mhz=nvml.get("gpu_clock_mhz"),
            gpu_throttle=bool(nvml.get("gpu_throttle", False)),
            fan_rpm=fan_rpm,
            battery_percent=float(battery.percent) if battery else None,
            plugged_in=bool(battery.power_plugged) if battery else None,
            estimated_power_w=estimated_power,
            ai_workload=ai_workload,
            top_process=top_process,
        )
