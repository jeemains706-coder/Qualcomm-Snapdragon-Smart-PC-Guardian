from __future__ import annotations


def recommendations(t: dict, risk_prob: float, risk_label: str) -> list[tuple[str, str]]:
    recs: list[tuple[str, str]] = []

    cpu_temp = t.get("cpu_temp_c")
    gpu_temp = t.get("gpu_temp_c")
    ram = t.get("ram_percent", 0) or 0
    vram = t.get("vram_percent", 0) or 0
    cpu = t.get("cpu_percent", 0) or 0
    gpu = t.get("gpu_percent", 0) or 0
    battery = t.get("battery_percent")
    plugged = t.get("plugged_in")
    ai = bool(t.get("ai_workload"))

    if risk_label == "HIGH":
        recs.append(("HIGH", f"Thermal/load risk is elevated ({risk_prob * 100:.0f}% model probability). Reduce sustained workload or improve airflow."))
    elif risk_label == "MEDIUM":
        recs.append(("WATCH", f"Thermal/load risk is moderate ({risk_prob * 100:.0f}% model probability). Keep an eye on temperature trends."))

    if cpu_temp is not None and cpu_temp >= 90:
        recs.append(("THERMAL", "CPU temperature is very high. Check vents/fans and avoid sustained heavy workloads until temperatures fall."))
    elif cpu_temp is not None and cpu_temp >= 80:
        recs.append(("THERMAL", "CPU temperature is elevated. Improve airflow and check whether background workloads are necessary."))

    if gpu_temp is not None and gpu_temp >= 86:
        recs.append(("GPU", "GPU temperature is high. Improve airflow and reduce sustained GPU load if performance starts falling."))
    elif gpu_temp is not None and gpu_temp >= 78:
        recs.append(("GPU", "GPU temperature is elevated. Watch for a rising trend or throttle events."))

    if ram >= 90:
        recs.append(("MEMORY", "RAM pressure is very high. Close unused applications or increase RAM capacity for heavier development workloads."))
    elif ram >= 80:
        recs.append(("MEMORY", "RAM usage is high. Large IDEs, browsers and AI tools may compete for memory."))

    if vram >= 90:
        recs.append(("VRAM", "VRAM is near capacity. Use a smaller batch size/model, lower texture/compute settings, or move some workload to system RAM when supported."))

    if ai and gpu < 15 and cpu > 70:
        recs.append(("GPU-UTIL", "An AI-related process is active while GPU utilization is low. Check whether the workload is actually using hardware acceleration."))

    if battery is not None and battery < 20 and not plugged:
        recs.append(("BATTERY", "Battery is below 20%. Reduce heavy workloads or connect power to avoid rapid discharge."))

    if plugged and battery is not None and battery >= 95 and (cpu > 80 or gpu > 80):
        recs.append(("POWER", "Heavy workload is running on AC power. This is appropriate for performance, but monitor temperature and sustained power."))

    if not recs:
        recs.append(("OK", "No immediate action is recommended. Continue monitoring the trend."))
    return recs
