# Qualcomm Snapdragon Smart PC Guardian

**Snapdragon® AI Lab Build & Present Challenge**

AI-powered monitoring, prediction and guidance for next-generation smart PCs.

## What this project solves

Modern laptops expose many hardware signals—CPU/GPU utilization, RAM/VRAM pressure, temperature, power and battery—but students usually see those values as disconnected numbers. The Smart PC Guardian combines them into one understandable view, estimates thermal/load risk, explains what is happening, and provides safe next actions.

The architecture is designed to extend naturally to Snapdragon AI PCs, including CPU/GPU/NPU-aware views and Windows-on-Arm compatibility guidance.

## Key capabilities

- Live CPU, RAM, battery and supported GPU telemetry
- Optional temperature, power and fan data through supported Windows sensor interfaces
- ML-based prototype thermal/load risk classification
- Explainable recommendations instead of opaque optimization
- CSV telemetry logging for later model training
- Interactive Streamlit + Plotly dashboard
- Separate Kaggle Appliances Energy Prediction experiment
- 20-run energy-model selection (4 model families × 5 seeds)
- Read-only design: no overclocking, undervolting, firmware changes or automatic process termination

## Architecture

```text
Windows telemetry
      ↓
Feature engineering
      ↓
AI inference ──────→ Risk state
      ↓                    ↓
Explainability      Recommendation engine
      ↓                    ↓
      └────── Interactive dashboard
                     ↓
                Telemetry history
```

## Windows setup

From the project directory:

```powershell
.\SETUP.bat
.\TRAIN.bat
.\RUN.bat
```

Then open `http://localhost:8501`.

The same actions are available under `scripts/` as PowerShell scripts.

## Kaggle dataset

Place `energydata_complete.csv` in `data/`, or let the download script retrieve it when supported. The dataset is used only for the separate energy-forecasting experiment.

## AI model note

The laptop thermal/load model in this repository is a **prototype** until it is trained and validated on real labeled laptop telemetry. The Kaggle energy model is a separate experiment using household/appliance energy data; it must not be interpreted as a direct laptop wattage or temperature model.

## Snapdragon / Windows-on-Arm direction

The project keeps a common telemetry schema so platform-specific adapters can be added later for Snapdragon CPU/GPU/NPU information. A future Arm compatibility assistant can classify software as native Arm64, emulated, or driver-dependent when authoritative compatibility data is available.

## Project materials

- `docs/Project_Report.docx` — detailed project report
- `docs/Short_Pitch.pptx` — competition pitch deck
- `docs/Short_Pitch.pdf` — pitch PDF
- `docs/500_char_submission_description.txt` — short submission description
- `assets/dashboard/` — prototype dashboard screenshots

## Safety and privacy

The prototype is read-only. It does not automatically modify firmware, fan curves, voltage settings or processes. Local telemetry CSVs, datasets and generated model binaries are ignored by Git.

## Author

**Rahul Das**  
B.Tech – Electronics & Communication Engineering (ECE)  
Lovely Professional University  
Snapdragon® AI Lab Build & Present Challenge, 2026

## References

- Qualcomm Snapdragon AI PC information: https://www.qualcomm.com/snapdragon/laptops-and-tablets/consumer/ai
- Microsoft Windows on Arm: https://learn.microsoft.com/en-us/windows/arm/overview
- Microsoft Arm emulation: https://learn.microsoft.com/en-us/windows/arm/apps-on-arm-x86-emulation
