# AI Laptop Guardian — Final Working Setup

This is a Windows-first, read-only laptop monitoring and AI energy dashboard.

## Fastest setup

1. Extract this folder anywhere, for example:

`C:\Users\rahul\Downloads\AI_Laptop_Guardian_FINAL_WORKING`

2. Open PowerShell in:

`...\AI_Laptop_Guardian_FINAL_WORKING\ai_laptop_guardian`

3. Run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup.ps1
.\scripts\train_all.ps1
.\scripts\run_dashboard.ps1
```

Open `http://localhost:8501`.

### Even easier

From the project folder you can use:

```powershell
.\SETUP.bat
```

and then:

```powershell
.\TRAIN.bat
```

and:

```powershell
.\RUN.bat
```

## Kaggle dataset

The energy model expects:

`data\energydata_complete.csv`

The download script uses KaggleHub. If download is unavailable, manually place the CSV in the `data` folder and run `TRAIN.bat` again.

## AI components

### Laptop Guardian model

Uses live Windows telemetry. The initial thermal-risk classifier is a prototype trained on synthetic telemetry. It is not real-world validated. The project is designed to replace this with real laptop telemetry labels later.

### Kaggle Energy AI

Uses the Kaggle/UCI Appliances Energy Prediction dataset. It trains 20 candidates: 4 model families × 5 seeds, with chronological train/validation/test splitting. The model predicts the dataset's `Appliances` target. It is not a laptop wattmeter.

## Hardware monitoring

CPU/RAM/battery use psutil. NVIDIA metrics use NVML when an NVIDIA GPU is available. Windows CPU temperature, power and fan readings are attempted through Libre Hardware Monitor WMI when available.

The app is read-only. It does not overclock, undervolt, change firmware, change fan curves, or terminate processes.

## Recommended order for Rahul

Use the three root files in this order:

1. `SETUP.bat` — creates `.venv` and installs packages.
2. Put your existing `energydata_complete.csv` (or `KAG_energydata_complete.csv`) in `data\`, or let the download script fetch it.
3. `TRAIN.bat` — trains the thermal prototype and the 20-run Kaggle energy model.
4. `RUN.bat` — starts the dashboard.

You can double-click the `.bat` files from File Explorer; PowerShell execution-policy errors are avoided because the batch files invoke PowerShell with `-ExecutionPolicy Bypass`.
