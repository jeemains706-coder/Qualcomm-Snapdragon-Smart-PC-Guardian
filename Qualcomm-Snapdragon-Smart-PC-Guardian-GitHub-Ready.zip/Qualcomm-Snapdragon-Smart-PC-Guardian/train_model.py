from pathlib import Path
from src.model import train_and_save

if __name__ == "__main__":
    result = train_and_save(Path("models/thermal_risk_model.joblib"))
    print(f"Model saved to {result['model_path']}")
    print(f"Prototype holdout accuracy: {result['accuracy']:.3f}")
    print("Important: this model uses synthetic telemetry labels; use real labeled data before making accuracy claims.")
