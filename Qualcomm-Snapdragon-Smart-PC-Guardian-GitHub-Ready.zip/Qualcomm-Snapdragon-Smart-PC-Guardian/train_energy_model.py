from __future__ import annotations

import argparse
from pathlib import Path

from src.energy_model import train_energy_model

ROOT = Path(__file__).resolve().parent

parser = argparse.ArgumentParser(description="Train AI Laptop Guardian's 20-run Kaggle energy model.")
parser.add_argument("--data", default=str(ROOT / "data" / "energydata_complete.csv"))
parser.add_argument("--output", default=str(ROOT / "models" / "kaggle_energy_model.joblib"))
args = parser.parse_args()

bundle = train_energy_model(args.data, args.output)
metrics = bundle["metrics"]

print("\n=== KAGGLE ENERGY AI: FINAL RESULT ===")
print(f"Runs:       {metrics['runs']}")
print(f"Best model: {metrics['best_model']} (seed {metrics['best_seed']})")
print(f"Rows:       {metrics['rows']:,}")
print(f"Train/Val/Test: {metrics['train_rows']:,} / {metrics['validation_rows']:,} / {metrics['test_rows']:,}")
print(f"MAE:        {metrics['mae_wh']:.2f} Wh")
print(f"RMSE:       {metrics['rmse_wh']:.2f} Wh")
print(f"R2:         {metrics['r2']:.4f}")
print(f"Saved:      {args.output}")
print("NOTE: This model predicts household/appliance energy, not laptop power, temperature, or throttling.")
