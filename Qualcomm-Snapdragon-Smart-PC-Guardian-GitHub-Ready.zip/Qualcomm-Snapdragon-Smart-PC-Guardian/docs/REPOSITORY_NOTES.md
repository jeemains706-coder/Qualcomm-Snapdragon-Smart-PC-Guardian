# Repository notes

The GitHub repository intentionally excludes local telemetry CSVs, the full Kaggle dataset, virtual environments, and generated model binaries. These files are machine-specific or generated artifacts. Recreate them using the setup and training instructions in the root README.
