$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (!(Test-Path $Python)) { throw "Virtual environment not found. Run .\scripts\setup.ps1 first." }

Write-Host "=== Training laptop thermal-risk prototype ===" -ForegroundColor Cyan
& $Python (Join-Path $ProjectRoot "train_model.py")

$Dataset = Join-Path $ProjectRoot "data\energydata_complete.csv"
$LegacyDataset = Join-Path $ProjectRoot "data\KAG_energydata_complete.csv"

if (!(Test-Path $Dataset) -and (Test-Path $LegacyDataset)) {
    Copy-Item $LegacyDataset $Dataset -Force
    Write-Host "Found KAG_energydata_complete.csv and created the canonical filename." -ForegroundColor Green
}

if (!(Test-Path $Dataset)) {
    Write-Host "Kaggle dataset not found. Attempting automatic download..." -ForegroundColor Yellow
    & $Python (Join-Path $ProjectRoot "download_kaggle_dataset.py")
}

if (!(Test-Path $Dataset)) {
    throw "Kaggle dataset is still missing. Put energydata_complete.csv in the data folder and run .\scripts\train_all.ps1 again."
}

Write-Host "=== Training 20-run Kaggle energy model ===" -ForegroundColor Cyan
& $Python (Join-Path $ProjectRoot "train_energy_model.py")

Write-Host "All training tasks completed." -ForegroundColor Green
Write-Host "Next: .\scripts\run_dashboard.ps1" -ForegroundColor Yellow
