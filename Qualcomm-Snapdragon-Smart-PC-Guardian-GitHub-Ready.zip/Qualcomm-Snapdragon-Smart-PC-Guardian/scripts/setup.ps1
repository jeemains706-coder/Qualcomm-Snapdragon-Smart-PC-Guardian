$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

Write-Host "=== AI Laptop Guardian Setup ===" -ForegroundColor Cyan

if (Test-Path ".venv\Scripts\python.exe") {
    Write-Host "Virtual environment already exists." -ForegroundColor Yellow
} else {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        py -m venv .venv
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        python -m venv .venv
    } else {
        throw "Python was not found. Install Python 3.11+ and make sure 'py' or 'python' is available in PowerShell."
    }
}

$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (!(Test-Path $Python)) {
    throw "Virtual environment Python executable was not created: $Python"
}

Write-Host "Upgrading pip..." -ForegroundColor Cyan
& $Python -m pip install --upgrade pip

Write-Host "Installing Python dependencies..." -ForegroundColor Cyan
& $Python -m pip install -r (Join-Path $ProjectRoot "requirements.txt")

New-Item -ItemType Directory -Force -Path (Join-Path $ProjectRoot "data") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $ProjectRoot "models") | Out-Null

Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Next: .\scripts\train_all.ps1" -ForegroundColor Yellow
