$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

$Python = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (!(Test-Path $Python)) { throw "Virtual environment not found. Run .\scripts\setup.ps1 first." }

& $Python -m streamlit run (Join-Path $ProjectRoot "app.py")
