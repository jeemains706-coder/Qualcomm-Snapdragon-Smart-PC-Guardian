from __future__ import annotations

import sys
from pathlib import Path
from datetime import datetime

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots
from streamlit_autorefresh import st_autorefresh

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from src.monitor import HardwareMonitor
from src.model import load_model, predict_risk
from src.recommendations import recommendations
from src.storage import append_csv
from src.energy_model import load_energy_model, predict_energy, train_energy_model

MODEL_PATH = ROOT / "models" / "thermal_risk_model.joblib"
ENERGY_MODEL_PATH = ROOT / "models" / "kaggle_energy_model.joblib"
ENERGY_DATA_PATH = ROOT / "data" / "energydata_complete.csv"
DATA_PATH = ROOT / "data" / "telemetry.csv"
REFRESH_MS_DEFAULT = 2500

st.set_page_config(page_title="AI Laptop Guardian", page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")

def find_energy_dataset() -> Path | None:
    candidates = [
        ENERGY_DATA_PATH,
        Path.home() / "Downloads" / "archive (2)" / "KAG_energydata_complete.csv",
        Path.home() / "Downloads" / "archive (2)" / "energydata_complete.csv",
        Path.home() / "OneDrive" / "Desktop" / "KAG_energydata_complete.csv",
        Path.home() / "OneDrive" / "Desktop" / "energydata_complete.csv",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


st.markdown("""
<style>
@keyframes pulseGlow { 0%,100%{box-shadow:0 0 0 0 rgba(99,102,241,.10)} 50%{box-shadow:0 0 28px 2px rgba(99,102,241,.22)} }
@keyframes pulseDot { 0%,100%{opacity:.35; transform:scale(.9)} 50%{opacity:1; transform:scale(1.1)} }
.guardian-title { font-size: 2.6rem; font-weight: 800; letter-spacing:-.04em; margin-bottom:.15rem; }
.guardian-subtitle { color:#7f8aa3; font-size:1rem; margin-bottom:1.2rem; }
.live-pill { display:inline-flex; align-items:center; gap:.45rem; padding:.35rem .7rem; border-radius:999px; background:rgba(16,185,129,.12); color:#10b981; font-weight:700; font-size:.82rem; }
.live-dot { width:.55rem; height:.55rem; border-radius:50%; background:#10b981; animation:pulseDot 1.5s infinite; }
.hero { padding:1.2rem 1.35rem; border-radius:22px; border:1px solid rgba(127,138,163,.16); background:linear-gradient(135deg, rgba(99,102,241,.12), rgba(16,185,129,.06)); animation:pulseGlow 4s infinite; }
.card { padding:1rem 1.05rem; border-radius:18px; border:1px solid rgba(127,138,163,.16); background:rgba(255,255,255,.025); }
.risk-high { color:#ef4444; font-weight:800; }
.risk-med { color:#f59e0b; font-weight:800; }
.risk-low { color:#10b981; font-weight:800; }
.small-muted { color:#7f8aa3; font-size:.82rem; }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def get_monitor() -> HardwareMonitor:
    return HardwareMonitor()

@st.cache_resource
def get_model():
    return load_model(MODEL_PATH)[0]

if not MODEL_PATH.exists():
    st.info("Thermal model not found. Creating the local prototype model automatically...")
    from src.model import train_and_save
    train_and_save(MODEL_PATH)
    st.rerun()

monitor = get_monitor()
model = get_model()
energy_bundle = load_energy_model(ENERGY_MODEL_PATH)

with st.sidebar:
    st.markdown("# AI Laptop Guardian 🛡️")
    refresh_sec = st.slider("Live refresh", 1, 10, 3, help="Lower values make the dashboard feel more real-time but increase system polling.")
    st.checkbox("Animated UI", value=True, key="animated")
    st.markdown("---")
    st.markdown("**Project mode**")
    st.caption("Read-only monitoring + AI recommendations")
    st.caption("No overclocking, undervolting, or automatic process killing.")
    detected_dataset = find_energy_dataset()
    if energy_bundle:
        st.success("Kaggle Energy AI: trained")
        st.caption(f"Model: {ENERGY_MODEL_PATH.name}")
    else:
        st.info("Kaggle Energy AI: awaiting dataset training")
        if detected_dataset:
            st.caption(f"Dataset detected: {detected_dataset.name}")
            if st.button("🚀 Train Kaggle Energy AI", use_container_width=True, type="primary"):
                with st.spinner("Training the Kaggle energy model…"):
                    result = train_energy_model(detected_dataset, ENERGY_MODEL_PATH)
                st.success(f"Training complete — R² = {result['metrics']['r2']:.3f}")
                st.rerun()
        else:
            st.caption("Put energydata_complete.csv in data/ or your Downloads folder.")

st_autorefresh(interval=int(refresh_sec * 1000), key="telemetry_refresh")
telemetry = monitor.sample().to_dict()
append_csv(DATA_PATH, telemetry)
risk_prob, risk_label = predict_risk(model, telemetry)
recs = recommendations(telemetry, risk_prob, risk_label)

if risk_label == "HIGH":
    risk_class, risk_emoji = "risk-high", "🔴"
elif risk_label == "MEDIUM":
    risk_class, risk_emoji = "risk-med", "🟠"
else:
    risk_class, risk_emoji = "risk-low", "🟢"

st.markdown('<div class="hero">', unsafe_allow_html=True)
st.markdown('<div class="guardian-title">🛡️ AI Laptop Guardian</div>', unsafe_allow_html=True)
st.markdown('<div class="guardian-subtitle">Predictive laptop health, energy intelligence and workload-aware recommendations</div>', unsafe_allow_html=True)
st.markdown('<span class="live-pill"><span class="live-dot"></span> LIVE TELEMETRY</span>', unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

st.write("")

# KPI row
kpi = st.columns(6)
kpi[0].metric("CPU", f"{telemetry['cpu_percent']:.0f}%")
kpi[1].metric("GPU", f"{telemetry['gpu_percent']:.0f}%")
kpi[2].metric("RAM", f"{telemetry['ram_percent']:.0f}%")
kpi[3].metric("GPU Temp", "N/A" if telemetry.get('gpu_temp_c') is None else f"{telemetry['gpu_temp_c']:.0f} °C")
kpi[4].metric("Battery", "N/A" if telemetry.get('battery_percent') is None else f"{telemetry['battery_percent']:.0f}%")
kpi[5].markdown(f"### {risk_emoji} <span class='{risk_class}'>{risk_label}</span><div class='small-muted'>AI risk {risk_prob*100:.1f}%</div>", unsafe_allow_html=True)

st.write("")
tab1, tab2, tab3, tab4 = st.tabs(["📡 Live Guardian", "⚡ Kaggle Energy AI", "🧠 AI Diagnosis", "🔧 Engineering"])

with tab1:
    left, right = st.columns([1.45, 1])
    with left:
        hist = pd.read_csv(DATA_PATH).tail(180) if DATA_PATH.exists() else pd.DataFrame()
        if not hist.empty and len(hist) >= 2:
            hist["time"] = pd.to_datetime(hist["timestamp"], unit="s", errors="coerce")
            if hist["time"].isna().all():
                hist["time"] = pd.to_datetime(hist["timestamp"], errors="coerce")
            fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=.12,
                                subplot_titles=("System utilization", "Thermal trend"))
            for col, label in [("cpu_percent", "CPU"), ("gpu_percent", "GPU"), ("ram_percent", "RAM")]:
                if col in hist:
                    fig.add_trace(go.Scatter(x=hist["time"], y=hist[col], mode="lines", name=label), row=1, col=1)
            for col, label in [("cpu_temp_c", "CPU °C"), ("gpu_temp_c", "GPU °C")]:
                if col in hist:
                    fig.add_trace(go.Scatter(x=hist["time"], y=hist[col], mode="lines", name=label), row=2, col=1)
            fig.update_yaxes(range=[0,100], row=1, col=1)
            fig.update_layout(height=540, margin=dict(l=0,r=0,t=45,b=0), hovermode="x unified", legend=dict(orientation="h"))
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        else:
            st.info("Collecting telemetry history…")

    with right:
        st.markdown("### Hardware snapshot")
        cards = st.columns(2)
        cards[0].metric("VRAM", f"{telemetry['vram_percent']:.0f}%")
        cards[1].metric("Power", "N/A" if telemetry.get('estimated_power_w') is None else f"{telemetry['estimated_power_w']:.1f} W")
        cards = st.columns(2)
        cards[0].metric("CPU Temp", "N/A" if telemetry.get('cpu_temp_c') is None else f"{telemetry['cpu_temp_c']:.1f} °C")
        cards[1].metric("Fan", "N/A" if telemetry.get('fan_rpm') is None else f"{telemetry['fan_rpm']:.0f} RPM")

        gauge = go.Figure(go.Indicator(
            mode="gauge+number", value=risk_prob*100,
            title={"text":"Predictive risk"},
            number={"suffix":"%"},
            gauge={"axis":{"range":[0,100]}, "bar":{"color":"#6366f1"},
                   "steps":[{"range":[0,30],"color":"rgba(16,185,129,.15)"},
                            {"range":[30,65],"color":"rgba(245,158,11,.15)"},
                            {"range":[65,100],"color":"rgba(239,68,68,.15)"}]}
        ))
        gauge.update_layout(height=250, margin=dict(l=20,r=20,t=55,b=0))
        st.plotly_chart(gauge, use_container_width=True, config={"displayModeBar": False})

        st.markdown("### Workload")
        st.write(f"AI-like workload: **{'Detected' if telemetry['ai_workload'] else 'Not detected'}**")
        st.write(f"Top CPU process: **{telemetry.get('top_process') or 'N/A'}**")
        st.write(f"GPU: **{telemetry.get('gpu_name') or 'Not detected'}**")
        st.write(f"Power source: **{'AC' if telemetry.get('plugged_in') else 'Battery' if telemetry.get('plugged_in') is not None else 'Unknown'}**")

with tab2:
    st.markdown("### ⚡ Kaggle Energy AI")
    st.caption("This model is trained on the Appliances Energy Prediction dataset and predicts appliance/household electricity demand. It is an energy-intelligence module, not a direct laptop wattmeter.")
    if energy_bundle is None:
        st.warning("No Kaggle-trained model found yet.")
        st.code("python train_energy_model.py", language="powershell")
        detected = find_energy_dataset()
        if detected:
            st.success(f"Dataset detected: `{detected}`. Use the **Train Kaggle Energy AI** button in the sidebar.")
        else:
            st.info("Place `energydata_complete.csv` inside the project's `data` folder, then train the model.")
    else:
        metrics = energy_bundle["metrics"]
        met = st.columns(4)
        met[0].metric("R²", f"{metrics['r2']:.3f}")
        met[1].metric("MAE", f"{metrics['mae_wh']:.1f} Wh")
        met[2].metric("RMSE", f"{metrics['rmse_wh']:.1f} Wh")
        met[3].metric("Training rows", f"{metrics['train_rows']:,}")

        form1, form2, form3 = st.columns(3)
        with form1:
            hour = st.slider("Hour", 0, 23, datetime.now().hour)
            minute = st.slider("Minute", 0, 50, (datetime.now().minute // 10) * 10, step=10)
            lights = st.slider("Lighting (Wh)", 0, 70, 10)
        with form2:
            t1 = st.slider("Room temp T1 (°C)", 10.0, 35.0, 21.0, 0.5)
            rh1 = st.slider("Humidity RH1 (%)", 20.0, 80.0, 40.0, 1.0)
            t6 = st.slider("Room temp T6 (°C)", 0.0, 35.0, 7.0, 0.5)
        with form3:
            rhout = st.slider("Outdoor humidity (%)", 20.0, 100.0, 70.0, 1.0)
            wind = st.slider("Wind speed", 0.0, 15.0, 4.0, 0.5)
            visibility = st.slider("Visibility", 1.0, 70.0, 40.0, 1.0)

        values = {
            "hour": hour, "minute": minute, "day_of_week": datetime.now().weekday(),
            "is_weekend": int(datetime.now().weekday() >= 5), "lights": lights,
            "T1": t1, "RH_1": rh1, "T6": t6, "RH_out": rhout,
            "Windspeed": wind, "Visibility": visibility, "Tdewpoint": t6 - 2,
        }
        predicted = predict_energy(energy_bundle, values)
        a, b = st.columns([1, 2])
        with a:
            st.metric("Predicted appliance energy", f"{predicted:.0f} Wh")
        with b:
            delta = predicted - float(metrics.get("mean_target_wh", predicted))
            st.caption("Prediction is for the Kaggle dataset target (`Appliances`). Use the scenario controls to explore how environmental/time variables affect predicted energy demand.")
            bar = go.Figure(go.Indicator(mode="number+gauge", value=predicted, title={"text":"Predicted demand (Wh)"}, gauge={"axis":{"range":[0,700]}, "bar":{"color":"#6366f1"}}))
            bar.update_layout(height=190, margin=dict(l=20,r=20,t=45,b=0))
            st.plotly_chart(bar, use_container_width=True, config={"displayModeBar": False})

        imp = pd.DataFrame({"feature": list(energy_bundle.get("feature_importance", {}).keys()), "importance": list(energy_bundle.get("feature_importance", {}).values())}).sort_values("importance", ascending=True).tail(12)
        if not imp.empty:
            st.markdown("#### Top learned drivers")
            fig_imp = go.Figure(go.Bar(x=imp["importance"], y=imp["feature"], orientation="h"))
            fig_imp.update_layout(height=360, margin=dict(l=10,r=10,t=20,b=10))
            st.plotly_chart(fig_imp, use_container_width=True, config={"displayModeBar": False})

with tab3:
    st.markdown("### 🧠 AI diagnosis")
    if telemetry.get("gpu_throttle"):
        st.warning("NVIDIA reports a current GPU clock-throttle reason. Check temperature, power limits and workload intensity before changing settings.")
    for level, message in recs:
        if level in {"HIGH", "THERMAL"}:
            st.error(f"**{level}:** {message}")
        elif level in {"WATCH", "GPU", "MEMORY", "VRAM", "GPU-UTIL", "BATTERY", "POWER"}:
            st.warning(f"**{level}:** {message}")
        else:
            st.success(message)

    st.markdown("#### AI-generated action plan")
    if risk_label == "HIGH":
        plan = ["Reduce sustained CPU/GPU load", "Check cooling airflow and fan operation", "Avoid extended operation at high temperatures", "Recheck telemetry after 2–3 minutes"]
    elif risk_label == "MEDIUM":
        plan = ["Watch temperature trend", "Close unnecessary background applications", "Prefer performance/battery mode appropriate to the workload", "Recheck before starting another heavy task"]
    else:
        plan = ["System is currently within the model's low-risk region", "Continue observing long-duration workload trends", "Collect more telemetry for personalized training"]
    for idx, item in enumerate(plan, 1):
        st.markdown(f"**{idx}.** {item}")

with tab4:
    st.markdown("### 🔧 Engineering transparency")
    st.write(f"Thermal model: `{MODEL_PATH.name}`")
    st.write(f"Energy model: `{ENERGY_MODEL_PATH.name if energy_bundle else 'not trained'}`")
    st.write(f"Telemetry log: `{DATA_PATH}`")
    st.write("The thermal model currently predicts risk from live hardware telemetry; the Kaggle model predicts the Kaggle dataset's appliance energy target.")
    st.write("For a publication/SIH-grade laptop model, collect real laptop telemetry (temperature, utilization, clocks, power and throttle state), create time-window labels and retrain on those observations.")
