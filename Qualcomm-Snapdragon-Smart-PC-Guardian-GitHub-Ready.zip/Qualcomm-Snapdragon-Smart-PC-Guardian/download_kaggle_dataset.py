from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "data"
OUT.mkdir(parents=True, exist_ok=True)
DST = OUT / "energydata_complete.csv"

if DST.exists() and DST.stat().st_size > 10_000:
    print(f"Dataset already exists: {DST}")
    print("Nothing to download.")
    raise SystemExit(0)

try:
    import kagglehub
except ImportError:
    raise SystemExit("kagglehub is not installed. Run setup first.")

# Public dataset handle used by KaggleHub for the Appliances Energy Prediction dataset.
HANDLE = "loveall/appliances-energy-prediction"

print(f"Downloading dataset: {HANDLE}")
print(f"Project data folder: {OUT}")

try:
    with TemporaryDirectory(prefix="ai_laptop_guardian_kaggle_") as tmp:
        downloaded = Path(kagglehub.dataset_download(HANDLE, output_dir=tmp))
        candidates = list(downloaded.rglob("energydata_complete.csv"))
        candidates += list(downloaded.rglob("KAG_energydata_complete.csv"))
        if not candidates:
            raise FileNotFoundError("energydata_complete.csv was not found inside the downloaded dataset.")
        shutil.copy2(candidates[0], DST)
except Exception as exc:
    print("Kaggle download failed.")
    print(str(exc))
    print("You can still continue: download energydata_complete.csv manually and place it in:")
    print(str(DST))
    sys.exit(1)

print(f"Dataset ready: {DST}")
