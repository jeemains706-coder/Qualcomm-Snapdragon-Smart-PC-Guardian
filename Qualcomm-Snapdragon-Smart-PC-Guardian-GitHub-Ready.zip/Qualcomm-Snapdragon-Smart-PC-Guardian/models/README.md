Models are created locally by the training scripts.

- thermal_risk_model.joblib
- kaggle_energy_model.joblib

The thermal model starts as a synthetic-data prototype. The Kaggle energy model is trained from data/energydata_complete.csv.
