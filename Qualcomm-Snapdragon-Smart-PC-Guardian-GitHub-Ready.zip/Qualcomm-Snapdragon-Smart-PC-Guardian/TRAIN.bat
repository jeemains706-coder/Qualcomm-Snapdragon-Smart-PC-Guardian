@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run SETUP.bat first.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\train_all.ps1"
if errorlevel 1 (
  echo Training failed.
  pause
  exit /b 1
)
echo Training completed successfully.
pause
