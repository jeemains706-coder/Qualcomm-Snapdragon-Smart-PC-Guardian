Place the Kaggle file `energydata_complete.csv` here.
